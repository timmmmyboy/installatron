Installatron Script for Known
=============================

Using the Installatron SDK:
---------------------------

You can read about building with the Installatron SDK on [their support site](http://installatron.com/developer/apps).
